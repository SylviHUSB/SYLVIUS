import os
from qgis.PyQt.QtWidgets import QAction, QMenu, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsWkbTypes, QgsCoordinateTransform,
    QgsCoordinateReferenceSystem, QgsGeometry, QgsPointXY, QgsSpatialIndex,
    QgsMapLayer, QgsLayerTreeNode  # Import nécessaire pour QgsMapLayer.VectorLayer
)
from collections import defaultdict, Counter

class MonPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.menu = None
        self.action_main = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.menu = QMenu("🔧 Outils Vecteurs", self.iface.mainWindow())

        # Actions du menu
        actions = [
             ("Fusion NRA → Infra", self.fusion_nra),
             ("NOMBRE d'entités par couches",self.verifier_couches_groupes),
            # Ajouter d'autres actions ici au fur et à mesure
        ]

        for label, func in actions:
            action = QAction(label, self.iface.mainWindow())
            action.triggered.connect(func)
            self.menu.addAction(action)

        self.action_main = QAction(QIcon(icon_path), "VERIF'INFRA", self.iface.mainWindow())
        self.action_main.setMenu(self.menu)

        self.iface.addPluginToMenu("🔎 Vérification Réseau Infra", self.menu.menuAction())
        self.iface.addToolBarIcon(self.action_main)

    def unload(self):
        self.iface.removePluginMenu("🔎 Vérification Réseau Infra", self.menu.menuAction())
        self.iface.removeToolBarIcon(self.action_main)


    def fusion_nra(self):
        from qgis.PyQt.QtWidgets import QInputDialog

        infra_group_name = "Infrastructure"

        # couches cibles à fusionner
        layer_names = [
            "Poteau", "Chambre", "Canalisation",
            "Support", "Tranchee", "Point GC",
            "Batiment", "Site", "Point Technique"
        ]

        project = QgsProject.instance()
        root = project.layerTreeRoot()
        infra_group = root.findGroup(infra_group_name)

        if not infra_group:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Fusion NRA",
                "Impossible de trouver 'Infrastructure'."
            )
            return

        # ✅ récupérer la liste de tous les groupes disponibles
        all_groups = [child.name() for child in root.children() if child.nodeType() == QgsLayerTreeNode.NodeGroup]

        if not all_groups:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Fusion NRA",
                "Aucun groupe disponible dans le projet."
            )
            return

        # ✅ demander à l'utilisateur de choisir le groupe NRA à fusionner
        nra_group_name, ok = QInputDialog.getItem(
            self.iface.mainWindow(),
            "Choisir un NRA",
            "Sélectionnez le groupe des SR à fusionner :",
            all_groups,
            0,
            False
        )

        if not ok or not nra_group_name:
            return  # annulation

        nra_group = root.findGroup(nra_group_name)
        if not nra_group:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "Fusion NRA",
                f"Impossible de trouver le groupe '{nra_group_name}'."
            )
            return

        # ✅ compteur par couche
        compteur_par_couche = {lname: 0 for lname in layer_names}

        for lname in layer_names:
            target_layer = None

            # chercher la couche cible dans Infra
            for child in infra_group.findLayers():
                if child.name() == lname:
                    target_layer = child.layer()
                    break

            if not target_layer:
                print(f"⚠️ Couche {lname} pas trouvée dans {infra_group_name}")
                continue

            # parcourir chaque sous-groupe NRA
            for subgroup in nra_group.children():
                if subgroup.nodeType() != QgsLayerTreeNode.NodeGroup:
                    continue

                for child in subgroup.findLayers():
                    if child.name() == lname:
                        source_layer = child.layer()
                        if not source_layer:
                            continue

                        features = [f for f in source_layer.getFeatures()]
                        if features:
                            target_layer.startEditing()
                            target_layer.addFeatures(features)
                            target_layer.commitChanges()
                            compteur_par_couche[lname] += len(features)
                            print(f"✅ {len(features)} {lname} copiés depuis {subgroup.name()}")

        # ✅ Construction du message final
        resume = f"Votre groupe '{nra_group_name}' contient :\n\n"
        for lname, count in compteur_par_couche.items():
            resume += f"- {lname} : {count} entités\n"

        QMessageBox.information(
            self.iface.mainWindow(),
            "Fusion NRA",
            resume
        )



    def verifier_couches_groupes(self):
        from qgis.PyQt.QtWidgets import QInputDialog, QMessageBox
        from qgis.core import QgsProject, QgsVectorLayer

        # Définition des groupes et leurs couches
        groupes = {
            'Infrastructure': ['Canalisation','Chambre','Point Technique','Poteau','Point GC','Site','Batiment'],
            'Cuivre': ['Cable Cuivre','SR','Manchon','PC'],
            'Fibre Optique': ['Cable Fo','SRO','Closer','BPE','PCO']
        }

        # Demande du groupe à vérifier
        groupe, ok = QInputDialog.getItem(None, "Choix du groupe", "Quel groupe veux-tu vérifier ?", list(groupes.keys()), 0, False)
        if not ok:
            return

        couches_cible = groupes[groupe]
        project = QgsProject.instance()

        rapport = f"<b>🔎 Vérification des couches pour le groupe '{groupe}' :</b><br><br>"

        for nom in couches_cible:
            layers = project.mapLayersByName(nom)
            if not layers:
                rapport += f"⚠ La couche <b>{nom}</b> est introuvable dans le projet.<br>"
                continue

            layer = layers[0]

            # Vérifier que c'est une couche vecteur
            if not isinstance(layer, QgsVectorLayer):
                rapport += f"ℹ La couche <b>{nom}</b> n'est pas vectorielle (ignorée).<br>"
                continue

            count = layer.featureCount()

            if count == 0:
                rapport += f"⚠ La couche <b>{nom}</b> ne contient aucune entité !<br>"
            else:
                rapport += f"✅ La couche <b>{nom}</b> contient {count} entité(s).<br>"

            # Cas particulier pour Batiment
            if nom.lower() == 'batiment' and count < 100:
                rapport += f"⚠ J'ai remarqué qu'il y a peu de bâtiments ({count}), tu confirmes que c'est bien le cas ?<br>"


        # Affichage résultat
        QMessageBox.information(None, "Vérification des couches", rapport)

