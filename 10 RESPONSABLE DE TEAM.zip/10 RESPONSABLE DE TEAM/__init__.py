def classFactory(iface):
    from .main import MonPlugin
    return MonPlugin(iface)
